import React, { useState, useEffect, useRef } from "react";
import { View, Text, TouchableOpacity, TextInput, Image, Animated, SafeAreaView, Modal, Platform, ScrollView, ToastAndroid, ActivityIndicator, Alert, StyleSheet, RefreshControl } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useDispatch, useSelector } from 'react-redux';
import { personalInfo } from "../../../Redux/Reducer/Client/Client.Reducer";
import { logout } from "../../../Redux/Reducer/Auth/Auth.reducers";
import SelectDropdown from 'react-native-select-dropdown';
import moment from "moment";
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import * as Sharing from 'expo-sharing';

import { AntDesign, Feather, Ionicons, Entypo, MaterialIcons } from "@expo/vector-icons";
import Style from "../../../Style/Style";
import BASE_URL from "../../../Urls/DomainUrl";

function showToast(message, onOk = null) {
  if (Platform.OS === 'android') {
    ToastAndroid.show(message, ToastAndroid.SHORT);
    if (onOk) {
      setTimeout(onOk, 2000);
    }
  } else {
    Alert.alert(
      '',
      message,
      [
        {
          text: 'OK',
          onPress: () => {
            if (onOk) onOk();
          },
        },
      ],
      { cancelable: false }
    );
  }
}

export default function RegDocument({ navigation }) {
 
  const dispatch = useDispatch();
  const { isLoading, personalInfoData, error } = useSelector((state) => state.client);
  const [scale] = useState(new Animated.Value(0));
  const [searchQuery, setSearchQuery] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [modalVisible1, setModalVisible1] = useState(false);
  const [docType, setDocType] = useState([]);
  const [docName, setDocName] = useState([]);
  const [docNo, setDocNo] = useState('');
  const [images, setImages] = useState([]);
  const [fileData, setFileData] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [selectedItem_id, setSelectedItem_id] = useState('');
  const [refresh, setRefresh] = useState(false);
  const [originalDocData, setOriginalDocData] = useState({});
  const logoutHandled = useRef(false);

  const pickImages = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });

    if (!result.canceled) {
      setImages([...images, result.assets[0]]);
    }
  };

  const pickSingleImage = async (replaceIndex) => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });
  
    if (!result.canceled) {
      const newImage = result.assets[0];
  
      const updatedImages = [...images];
      updatedImages[replaceIndex] = newImage; // replace image at index
      setImages(updatedImages);
    }
  };

  useEffect(() => {
    Animated.timing(scale, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
  }, []);

  useEffect(() => {
        dispatch(personalInfo());
   }, [dispatch]);

  const regData = personalInfoData?.documentData || [];

  const filteredData = regData.filter(item =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.number.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getDocType = async ()=>{
    if (logoutHandled.current) return;
     let token = await AsyncStorage.getItem("token");
     if(!token) {
      navigation.navigate('Splash');
      return;
    }
    const myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer " + token);
    myHeaders.append("Content-Type", "application/json");
    
    const raw = JSON.stringify({
      "text": "",
      "sort": false,
      "status": "",
      "type": "",
      "isPagination": false
    });
    
    const requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow"
    };
    
    fetch(`${BASE_URL}/client/document/documentType`, requestOptions)
     .then((response) => response.json())
      .then((result) => {
        if(result.statusCode === 200){
          setDocType(result?.data?.docs);
        }else if (result.statusCode === 401) {
          if (!logoutHandled.current) {
            logoutHandled.current = true; // Flag to prevent multiple logouts
            showToast("Session expired. Please log in again.", () => {
              dispatch(logout()); // Dispatch logout action when OK is pressed
              navigation.navigate('Autologin'); // Navigate to autologin page
            });
          }
        }else{
          console.log(result.message)
        }
      })
      .catch((error) => console.error(error));
  }

  const uploadFile = async () => {
    if (images.length === 0) {
      showToast("Please select at least one image.");
      return;
    }
    if (!docName || !docType) {
      showToast("Please select document type and enter document name.");
      return;
    }
    try {
      if (logoutHandled.current) return;
       let token = await AsyncStorage.getItem("token");
       if(!token) {
        navigation.navigate('Splash');
        return;
      }
      const formData = new FormData();
  
      images.forEach((img, index) => {
        formData.append("filePath", {
          uri: img.uri,
          name: `image_${index}.jpg`, 
          type: 'image/jpeg', 
        });
      });
  
      formData.append("fileLocation", "/clientImage");
      formData.append("isMultiple", "true");
      formData.append("isVideo", "false");
  
      const requestOptions = {
        method: "POST",
        headers: {
          "Authorization": "Bearer " + token,
          "Content-Type": "multipart/form-data",
        },
        body: formData,
      };
  
      const response = await fetch(`${BASE_URL}/client/auth/fileUpload`, requestOptions);
      const result = await response.json();
  
      if (result.statusCode === 200) {
        showToast(result.message);
        // console.log("Uploaded data:", result);
        setFileData(result.data);
        uploadDoc(result.data);
      }else if (result.statusCode === 401) {
        if (!logoutHandled.current) {
          logoutHandled.current = true; // Flag to prevent multiple logouts
          showToast("Session expired. Please log in again.", () => {
            dispatch(logout()); // Dispatch logout action when OK is pressed
            navigation.navigate('Autologin'); // Navigate to autologin page
          });
        }
      } else {
        console.log("Upload failed:", result.message);
        showToast(result.message || "Upload failed.");
      }
    } catch (error) {
      console.error("Upload error:", error);
      showToast("Something went wrong.");
    }
  };

  const uploadDoc = async (data) => {
    if (logoutHandled.current) return;
     let token = await AsyncStorage.getItem("token");
     if(!token) {
      navigation.navigate('Splash');
      return;
    }
    const myHeaders = new Headers();
    myHeaders.append("Authorization", "Bearer " + token);
    myHeaders.append("Content-Type", "application/json");

    const hasEdited =
    docName !== originalDocData.name ||
    docNo !== originalDocData.number ||
    images.map(img => img.uri).join() !== originalDocData.images.join();

    const isVerified = hasEdited ? false : originalDocData.isVerified ?? false

      const raw = JSON.stringify({
        "type": "documents",
        "documents": [
          {
            "_id": selectedItem_id || null,
            "userId": personalInfoData?._id,
            "name": docName,
            "number": docNo,
            "filePath": data,
            "isVerified": isVerified
          },
        ],
      });
      
      const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow"
      };

    fetch(`${BASE_URL}/client/document/update`, requestOptions)
     .then((response) => response.json())
      .then((result) => {
        if(result.statusCode === 200){
          // console.log(result);
          setImages([]);
          setDocName([]);
          setDocNo('');
          dispatch(personalInfo());
          showToast(result.message);
        }else if (result.statusCode === 401) {
          if (!logoutHandled.current) {
            logoutHandled.current = true; // Flag to prevent multiple logouts
            showToast("Session expired. Please log in again.", () => {
              dispatch(logout()); // Dispatch logout action when OK is pressed
              navigation.navigate('Autologin'); // Navigate to autologin page
            });
          }
        }else{
          showToast(result.message || "Document upload failed.");
        }
      })
      .catch((error) => console.error(error));
  }

   const downloadFile = async (fileUrl) => {
  if (!fileUrl) {
    showToast("No file found to download.");
    return;
  }

  // Check if token exists
  let token = await AsyncStorage.getItem("token");
  if (!token) {
    showToast("Session expired. Please log in again.");
    navigation.navigate('Splash'); // Navigate to the login screen
    return;
  }

  try {
    const filename = fileUrl.split('/').pop();
    const fileUri = FileSystem.documentDirectory + filename;

    const downloadResumable = FileSystem.createDownloadResumable(
      fileUrl,
      fileUri
    );

    const { uri } = await downloadResumable.downloadAsync();

    if (Platform.OS === 'android') {
      const { status } = await MediaLibrary.requestPermissionsAsync();
      if (status === 'granted') {
        const asset = await MediaLibrary.createAssetAsync(uri);
        await MediaLibrary.createAlbumAsync('Documents', asset, false);
        showToast("Download complete and saved to Documents folder.");
      } else {
        showToast("Permission denied to save the file.");
      }
    } else if (Platform.OS === 'ios') {
      const isAvailable = await Sharing.isAvailableAsync();
      if (isAvailable) {
        await Sharing.shareAsync(uri); // Share and allow saving to Files
      } else {
        showToast("Sharing not available on this device.");
      }
    }
  } catch (e) {
    console.error("Download error:", e);
    showToast("Download failed.");
  }
};

  useEffect(()=>{
    getDocType();
  },[])

   const onRefresh = ()=>{
      setRefresh(true);
      dispatch(personalInfo());
      setTimeout(()=>{
        setRefresh(false);
      },2000)
    }

    const handleClose =()=>{
      setImages([]);
      setDocName([]);
      setDocNo('');
      setModalVisible(!modalVisible);
    }
    const handleClose1 =()=>{
      setImages([]);
      setDocName([]);
      setDocNo('');
      setModalVisible1(!modalVisible1);
    }

    useEffect(() => {
      if (modalVisible1 && selectedItem) {
        const initialDoc = {
          name: selectedItem.name || '',
          number: selectedItem.number || '',
          images: selectedItem.filePath?.map(path => path) || [],
          isVerified: selectedItem.isVerified ?? false
        };
    
        setOriginalDocData(initialDoc);
        setSelectedItem_id(selectedItem._id || "")
        setDocName(initialDoc.name);
        setDocNo(initialDoc.number);
    
        const formattedImages = initialDoc.images.map(path => ({
          uri: path,
        }));
        setImages(formattedImages);
      }
    }, [modalVisible1, selectedItem]);

  return (
    <SafeAreaView style={{ flex:1, backgroundColor:Style.headerBgColor }}>
      <Animated.View style={{ paddingHorizontal:20, transform: [{ scale }] }}>
        <View style={{ flexDirection: 'row', width: '100%', marginTop: 0, alignItems:'center' }}>
          <TouchableOpacity onPress={()=> navigation.goBack()} style={{ width: 50, height: 50, justifyContent: 'center', alignItems: 'flex-start' }}>
             <AntDesign name="arrowleft" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={{color: '#fff',fontSize: 14, fontFamily:'Poppins-SemiBold', flex: 1, }}>Registration Documents</Text>
        </View>
        <View style={{flexDirection: 'row',alignItems: 'center', marginTop: 20, marginBottom: 20,}}>
          <View style={{flex: 8, flexDirection: 'row', alignItems: 'center', backgroundColor:Style.basicbgColor,borderRadius: 50, height: 50, elevation: 4 }}>
            <TextInput placeholder="Search" value={searchQuery} onChangeText={setSearchQuery} style={{flex: 9, fontSize: 18,padding: 10,paddingLeft: 20,}} />
            <TouchableOpacity style={{ flex: 1.5, justifyContent: 'center', alignItems: 'center' }}>
              <Image source={require('../../../assets/oui_search.png')} resizeMode='contain'style={{ width: 20, height: 20,}} />
            </TouchableOpacity>
          </View>
          <TouchableOpacity onPress={()=> navigation.navigate('Notifikation')} style={{ flex:1.5, width: 50, height: 50, borderRadius: 50, justifyContent: 'center',alignItems:"flex-end" }}>
             <Feather name="bell" size={28} color="#fff" />
          </TouchableOpacity>
        </View>
      </Animated.View>

      <View style={{ flex:1, backgroundColor:Style.primaryBgColor, borderTopStartRadius:20, borderTopEndRadius:20, padding:20 }} >
        <Animated.View style={{flex:1, transform: [{ scale }] }}>
          <View style={{ width:"100%", flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingBottom:10 }} >
            <Text style={{ fontSize:14, fontFamily:'Poppins-SemiBold', color:Style.headerBgColor }}>Registration Documents</Text>
              <TouchableOpacity onPress={()=> setModalVisible(true)} style={{ flexDirection:'row', gap:10, backgroundColor:Style.headerBgColor, paddingHorizontal:10, height:40, justifyContent:'center', alignItems:'center', borderRadius:6 }} >
                <Feather name="upload" size={20} color="#fff" />
                <Text style={{ color:'#fff', fontFamily:'Poppins-Medium', fontSize:12, }} >Documents</Text>
              </TouchableOpacity>
          </View>
           <Modal
             animationType="slide"
             transparent={true}
             visible={modalVisible}
             onRequestClose={() => setModalVisible(!modalVisible)}
           >
             <View style={styles.modalBackground}>
               <View style={styles.modalContainer}>
                 <View style={styles.modalHeader}>
                   <Text style={styles.modalTitle}>Upload Documents</Text>
                   <TouchableOpacity onPress={handleClose} style={styles.closeButton}>
                     <Ionicons name="close-sharp" size={32} color='#fff' />
                   </TouchableOpacity>
                 </View>
                  <View style={{ padding:10 }}>
                    <TouchableOpacity style={{ width:'100%', height:50, backgroundColor:"#f8f9fa", borderRadius:6, marginBottom:20, justifyContent:'space-between'}} >
                    {Array.isArray(docType) && docType.length > 0 ? (
                      <SelectDropdown
                        data={docType}
                        defaultValue={docType.find(d => d.name === docName) || null}
                        onSelect={(selecteddocType, index) => {
                          setDocName(selecteddocType.name);
                          // showToast(`Selected: ${selecteddocType.name}`);
                        }}
                        renderButton={(selecteddocType, isOpened) => (
                          <View style={styles.dropdownButtonStyle}>
                            <Text style={styles.dropdownButtonTxtStyle}>
                              {selecteddocType ? selecteddocType.name : 'Select Document'}
                            </Text>
                            <Entypo
                              name={isOpened ? 'chevron-up' : 'chevron-down'}
                              style={styles.dropdownButtonArrowStyle}
                            />
                          </View>
                        )}
                        renderItem={(item, index, isSelected) => (
                          <View
                            style={{
                              ...styles.dropdownItemStyle,
                              ...(isSelected && { backgroundColor: '#D2D9DF' }),
                            }}
                          >
                            <Text style={styles.dropdownItemTxtStyle}>
                              {item.name}
                            </Text>
                          </View>
                        )}
                        showsVerticalScrollIndicator={false}
                        dropdownStyle={styles.dropdownMenuStyle}
                      />
                    ) : (
                      <View style={styles.dropdownButtonStyle}>
                        <Text style={styles.dropdownButtonTxtStyle}>No data found</Text>
                        <Entypo
                          name="chevron-down"
                          style={styles.dropdownButtonArrowStyle}
                        />
                      </View>
                    )}
                   </TouchableOpacity>
                    <View style={{ width:'100%', height:50,  backgroundColor:"#fff", borderRadius:6, marginBottom:20, }}>
                        <TextInput value={docNo} onChangeText={value => setDocNo(value)} placeholder="Enter Document Number" style={{ flex: 1, backgroundColor: '#fff', color:Style.headerBgColor, borderRadius: 5, padding: 5, paddingLeft:15 }} />
                    </View>
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
                      {images.map((img, index) => (
                        <TouchableOpacity
                          key={index}
                          style={{
                            width: '48%',
                            height: 150,
                            borderWidth: 1,
                            borderRadius: 10,
                            justifyContent: 'center',
                            alignItems: 'center',
                          }}
                          disabled={true}
                        >
                          <Image
                            source={{ uri: img.uri }}
                            style={{ width: '100%', height: '100%', borderRadius: 10 }}
                          />
                        </TouchableOpacity>
                      ))}
                
                      {/* Show new image picker if less than max (optional limit) */}
                      {images.length < 5 && (
                        <TouchableOpacity
                          onPress={pickImages}
                          style={{
                            width: '48%',
                            height: 150,
                            borderWidth: 1,
                            borderRadius: 10,
                            justifyContent: 'center',
                            alignItems: 'center',
                          }}
                        >
                          <Ionicons name="image-outline" size={40} color="#999" />
                        </TouchableOpacity>
                      )}
                    </View>
                  </View>
                      <TouchableOpacity onPress={uploadFile} style={{ width:'90%', height:45, justifyContent:'center', alignItems:'center', alignSelf:'center', backgroundColor:Style.headerBgColor, borderRadius:6, position:'absolute', bottom:20,  }} >
                         <Text style={{ color:'#fff', fontFamily:'Poppins-Medium', fontSize:12, }} >Upload</Text>
                      </TouchableOpacity>
                 </View>
               </View>
           </Modal>
           <ScrollView refreshControl={<RefreshControl refreshing={refresh} onRefresh={onRefresh} />} showsVerticalScrollIndicator={false} style={{ flex:1 }}>
                <View>
                   {
                     isLoading?(
                       <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: 20 }}>
                           <ActivityIndicator size="large" color="#0000ff" />
                       </View>
                     ):(
                      filteredData.length > 0 ?(
                        filteredData.map((item, index) => {
                          return(
                              <View key={index} style={{ width:'100%', backgroundColor:Style.basicbgColor, borderRadius:10, marginBottom:10, padding:10 }} >
                                <View style={{ width:"100%", flexDirection:'row', justifyContent:'space-between', alignItems:'center' }} >
                                   <View style={{ flexDirection:'row', gap:10, alignItems:'center' }}>
                                     <MaterialIcons name="verified-user" size={16} color={item.isVerified ? 'green' : 'red'} />
                                     <Text style={{ fontSize:16, fontWeight:"500", color:Style.headerBgColor }}>{item.name}</Text>
                                   </View>
                                   <View style={{ flexDirection:'row', gap:10 }} >
                                    <TouchableOpacity onPress={() => {
                                        if (item.filePath.length === 0) {
                                          showToast("No images available to download.");
                                        } else {
                                          item.filePath.forEach(url => downloadFile(url));
                                        }
                                      }} style={{ width:30, height:30, justifyContent:'center', alignItems:'center', borderRadius:5 }} >
                                       <Feather name="download" size={22} color={Style.placeHolderTextColor} />
                                    </TouchableOpacity>
                                    <TouchableOpacity onPress={() => {
                                       setSelectedItem(item);
                                       setModalVisible1(true);
                                     }} style={{ width:30, height:30, justifyContent:'center', alignItems:'center', borderRadius:5 }} >
                                       <Feather name="edit" size={22} color={Style.headerBgColor} />
                                    </TouchableOpacity>
                                   </View>
                                </View>
                                 {
                                  item.filePath.map((fpath, index)=>{
                                    return(
                                      <Text key={index} style={{ fontSize:14, fontFamily:'Poppins-SemiBold', color:Style.secondryTextColor }}>{fpath.split('/').pop()}</Text>
                                    )
                                  })
                                 }
                                 <View style={{ flexDirection:'row', alignItems:'center', paddingVertical:5 }}>
                                    <Text style={{ fontSize:16, fontFamily:'Poppins-SemiBold', color:Style.headerBgColor }}>Doc No. : </Text>
                                    <Text style={{ fontSize:14, fontFamily:'Poppins-SemiBold', color:Style.secondryTextColor }}>{item.number}</Text>
                                 </View>
                              </View>
                           )
                        })
                      ):(
                        <Text style={{ fontSize: 18, fontWeight: '600', color: Style.secondryTextColor, textAlign: 'center', paddingVertical: 20 }}>
                            No Data Found
                        </Text>
                      )
                     )
                   }
                   <Modal
                     animationType="slide"
                     transparent={true}
                     visible={modalVisible1}
                     onRequestClose={() => setModalVisible1(!modalVisible1)}
                   >
                     <View style={styles.modalBackground}>
                       <View style={styles.modalContainer}>
                         <View style={styles.modalHeader}>
                           <Text style={styles.modalTitle}>Update Documents</Text>
                           <TouchableOpacity onPress={handleClose1} style={styles.closeButton}>
                             <Ionicons name="close-sharp" size={32} color='#fff' />
                           </TouchableOpacity>
                         </View>
                          <View style={{ padding:10 }}>
                            <TouchableOpacity style={{ width:'100%', height:50, backgroundColor:"#f8f9fa", borderRadius:6, marginBottom:20, justifyContent:'space-between'}} >
                             <SelectDropdown
                               data={docType || []}
                               defaultValue={
                                 docType?.find(d => d.name === docName) || null
                               }
                               onSelect={(selecteddocType, index) => {
                                 setDocName(selecteddocType.name);
                                //  showToast(`Selected: ${selecteddocType.name}`);89
                               }}
                               renderButton={(selecteddocType, isOpened) => (
                                 <View style={styles.dropdownButtonStyle}>
                                   <Text style={styles.dropdownButtonTxtStyle}>
                                     {selecteddocType ? selecteddocType.name : 'Select Document'}
                                   </Text>
                                   <Entypo
                                     name={isOpened ? 'chevron-up' : 'chevron-down'}
                                     style={styles.dropdownButtonArrowStyle}
                                   />
                                 </View>
                               )}
                               renderItem={(item, index, isSelected) => (
                                 <View
                                   style={{
                                     ...styles.dropdownItemStyle,
                                     ...(isSelected && { backgroundColor: '#D2D9DF' }),
                                   }}
                                 >
                                   <Text style={styles.dropdownItemTxtStyle}>
                                     {item.name}
                                   </Text>
                                 </View>
                               )}
                               showsVerticalScrollIndicator={false}
                               dropdownStyle={styles.dropdownMenuStyle}
                             />
                           </TouchableOpacity>
                            <View style={{ width:'100%', height:50,  backgroundColor:"#fff", borderRadius:6, marginBottom:20, }}>
                                <TextInput value={docNo} onChangeText={value => setDocNo(value)} placeholder="Enter Document Number" style={{ flex: 1, backgroundColor: '#fff', color:Style.headerBgColor, borderRadius: 5, padding: 5, paddingLeft:15 }} />
                            </View>
                            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
                             {images.map((img, index) => (
                               <View key={index} style={{ width: '48%', height: 150, borderWidth: 1, borderRadius: 10, overflow: 'hidden', position: 'relative', }}>
                                 <Image
                                   source={{ uri: img.uri }}
                                   style={{ width: '100%', height: '100%' }}
                                 />
                             
                                 <TouchableOpacity
                                   onPress={() => pickSingleImage(index)}
                                   style={{ position: 'absolute', top: 5, right: 5, backgroundColor: '#000000aa', padding: 5, borderRadius: 20,}} >
                                   <Feather name="edit" size={18} color="#fff" />
                                 </TouchableOpacity>
                               </View>
                             ))}
                              {images.length < 5 && (
                                <TouchableOpacity onPress={pickImages} style={{ width: '48%', height: 150, borderWidth: 1, borderRadius: 10, justifyContent: 'center', alignItems: 'center', }} >
                                  <Ionicons name="image-outline" size={40} color="#999" />
                                </TouchableOpacity>
                              )}
                            </View>
                          </View>
                              <TouchableOpacity onPress={uploadFile} style={{ width:'90%', height:45, justifyContent:'center', alignItems:'center', alignSelf:'center', backgroundColor:Style.headerBgColor, borderRadius:6, position:'absolute', bottom:20,  }} >
                                 <Text style={{ color:'#fff', fontFamily:'Poppins-Medium', fontSize:12, }} >Upload</Text>
                              </TouchableOpacity>
                         </View>
                       </View>
                   </Modal>
                </View>
           </ScrollView>
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  dropdownButtonStyle: {
      width: "100%",
      height: 50,
      backgroundColor: Style.basicbgColor,
      borderRadius: 6,
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      paddingHorizontal: 12,
      elevation:1
    },
    dropdownButtonTxtStyle: {
      flex: 1,
      fontSize: 14,
      fontWeight: '600',
      color: Style.headerBgColor,
    },
    dropdownButtonArrowStyle: {
      fontSize: 28,
    },
    dropdownButtonIconStyle: {
      fontSize: 28,
      marginRight: 8,
    },
    dropdownMenuStyle: {
      backgroundColor: '#E9ECEF',
      borderRadius: 8,
    },
    dropdownItemStyle: {
      width: '100%',
      flexDirection: 'row',
      paddingHorizontal: 12,
      justifyContent: 'center',
      alignItems: 'center',
      paddingVertical: 8,
    },
    dropdownItemTxtStyle: {
      flex: 1,
      fontSize: 18,
      fontWeight: '500',
      color: Style.headerBgColor,
    },
    dropdownItemIconStyle: {
      fontSize: 28,
      marginRight: 8,
    },
  modalBackground: {
      flex: 1,
      backgroundColor: '#00000095',
      justifyContent: "center",
      padding: 0,
    },
    modalContainer: {
      width: '100%',
      backgroundColor: Style.primaryBgColor,
      padding: 0,
      borderRadius: 5,
      flex:1,
      marginTop:60,
    },
    modalHeader: {
      width: '100%',
      height: 50,
      backgroundColor: Style.headerBgColor,
      flexDirection: 'row',
      justifyContent: "space-between",
      alignItems: 'center',
      padding: 10,
    },
    modalTitle: {
      fontFamily: 'Roboto-Bold',
      color: "#fff",
      fontSize: 14,
    },
    closeButton: {
      width: 40,
      height: 40,
      justifyContent: 'center',
      alignItems: 'center',
    },
});